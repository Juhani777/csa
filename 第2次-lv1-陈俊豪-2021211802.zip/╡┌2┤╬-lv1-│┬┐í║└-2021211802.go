//@program:     class2-lv1
//@author:      chenjunhao
//@create:      2021-11-14
package main

import (
	"fmt"
)

type person struct {
	name  string
	age    int
	gender  string
}

type dove interface {
	gugugu()
}

type repeater interface {
	repeat(string)
}

type lemonmonster interface {
	lemon()
}

type braekpromise interface {
	noface()
}

func (p *person) gugugu(){
	fmt.Println(p.name,"又鸽了")
}
func(p *person) repeat(word string){
	fmt.Println(word)
}
func(p*person) lemon(){
	fmt.Println("我酸了")
}
func(p*person) noface(){
	fmt.Println("啪啪啪打脸")
}
func main(){
	 p := &person{
		name:  "1cm",
		age:   18,
		gender: "male",
	}
	p.gugugu()
	p.lemon()
	p.noface()
	p.repeat("hello world")
}
